@echo off
chcp 65001 >nul 2>&1
title RadioContest AI - F6KQJ/P

echo.
echo  ====================================================
echo    RadioContest AI v3.0 -- F6KQJ/P JN15XC
echo    Rallye des Points Hauts 2026
echo  ====================================================
echo.

:: Aller dans le dossier du script (important si lance depuis ailleurs)
cd /d "%~dp0"
echo  Dossier : %~dp0
echo.

:: Verifier que serveur.py existe
if not exist "serveur.py" (
    echo  [ERREUR] serveur.py introuvable dans ce dossier !
    echo  Verifiez que vous avez bien extrait le ZIP complet.
    echo.
    pause
    exit /b 1
)

:: Chercher Python
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERREUR] Python non trouve dans le PATH !
    echo.
    echo  Solutions :
    echo  1. Installer Python : https://www.python.org/downloads/
    echo     IMPORTANT : cocher "Add Python to PATH"
    echo  2. Redemarrer ce fichier apres installation
    echo.
    pause
    exit /b 1
)

:: Afficher version Python
echo  Python trouve :
python --version
echo.

:: Verifier port 8080 libre
netstat -an | find "8080" | find "LISTEN" >nul 2>&1
if %errorlevel% equ 0 (
    echo  [ATTENTION] Le port 8080 est deja utilise !
    echo  Fermez l autre application qui utilise ce port.
    echo.
    pause
    exit /b 1
)

echo  Demarrage du serveur...
echo  Ne fermez pas cette fenetre pendant le concours !
echo.

:: Ouvrir le navigateur apres 3 secondes
start "" /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:8080/logbook.html"

:: Lancer Python et afficher les erreurs
python -u serveur.py

echo.
echo  Le serveur s est arrete (code: %errorlevel%)
echo.
pause
