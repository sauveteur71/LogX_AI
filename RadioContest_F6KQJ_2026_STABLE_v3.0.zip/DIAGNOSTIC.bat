@echo off
chcp 65001 >nul 2>&1
title Diagnostic RadioContest
echo.
echo === DIAGNOSTIC RadioContest AI ===
echo.

cd /d "%~dp0"

echo [1] Dossier courant:
echo %CD%
echo.

echo [2] Fichiers presents:
dir /b *.py *.html *.json *.bat 2>nul
echo.

echo [3] Python:
where python 2>nul || echo PYTHON NON TROUVE
python --version 2>nul || echo PYTHON NON INSTALLE
echo.

echo [4] Port 8080:
netstat -an | find "8080" || echo Port 8080 libre
echo.

echo [5] Test demarrage Python (5 secondes):
python -u serveur.py
echo Code retour: %errorlevel%
echo.

pause
